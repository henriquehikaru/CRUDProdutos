package com.template;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;

public class MainController {

    @FXML
    private Button btnSalvar;

    @FXML
    private TextField txtDescricao;

    @FXML
    private TextField txtCategoria;

    @FXML
    private TextField txtPreco;

    @FXML
    private TableView<ProdutoDTO> tblProdutos;

    @FXML
    private TableColumn<ProdutoDTO, Integer> colId;

    @FXML
    private TableColumn<ProdutoDTO, String> colDescricao;

    @FXML
    private TableColumn<ProdutoDTO, String> colCategoria;

    @FXML
    private TableColumn<ProdutoDTO, Double> colPreco;

    @FXML
    private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id_produto"));
        colDescricao.setCellValueFactory(new PropertyValueFactory<>("descricao"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        carregarProdutos();
        carregarCampos();
    }

    @FXML
    private void carregarProdutos() {
        ProdutoDAO objProdutoDAO = new ProdutoDAO();

        ArrayList<ProdutoDTO> listaProdutos =
                objProdutoDAO.selecionarProduto();

        tblProdutos.setItems(
                FXCollections.observableArrayList(listaProdutos)
        );
    }

    @FXML
    private void carregarCampos() {
        ProdutoDTO objProdutoDTO = tblProdutos.getSelectionModel().getSelectedItem();

        if (objProdutoDTO != null) {
            txtDescricao.setText(objProdutoDTO.getDescricao());
            txtCategoria.setText(objProdutoDTO.getCategoria());
            txtPreco.setText(Double.toString(objProdutoDTO.getPreco()));
        }
    }

    @FXML
    private void limpaCampos() {
            txtDescricao.setText(null);
            txtCategoria.setText(null);
            txtPreco.setText(null);
    }

    @FXML
    private void onSalvarProduto() {

        ProdutoDTO produtoSelecionado = tblProdutos.getSelectionModel().getSelectedItem();

        if (produtoSelecionado != null) {

            produtoSelecionado.setDescricao(txtDescricao.getText());
            produtoSelecionado.setCategoria(txtCategoria.getText());

            double preco = Double.parseDouble(txtPreco.getText());
            produtoSelecionado.setPreco(preco);

            ProdutoDAO dao = new ProdutoDAO();
            dao.alterarProduto(produtoSelecionado);
        }

        else {
            ProdutoDTO novoProduto = new ProdutoDTO();
            novoProduto.setDescricao(txtDescricao.getText());
            novoProduto.setCategoria(txtCategoria.getText());
            novoProduto.setPreco(Double.parseDouble(txtPreco.getText()));

            new ProdutoDAO().cadastrarProduto(novoProduto);
        }
        limpaCampos();
        carregarProdutos();
    }

    @FXML
    private void onExcluirProduto() {

        ProdutoDTO produtoSelecionado = tblProdutos.getSelectionModel().getSelectedItem();

        if (produtoSelecionado != null) {
            ProdutoDAO dao = new ProdutoDAO();
            dao.excluirProduto(produtoSelecionado);
            limpaCampos();
            carregarProdutos();
        }
    }
}